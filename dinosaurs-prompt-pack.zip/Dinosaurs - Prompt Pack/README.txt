DINOSAURS, PROMPT PACK
by Ratmir / Ridge

WHAT IS INSIDE
Five shots. Each folder holds the full prompt exactly as it was run and the
finished clip it produced.

  01 The Leash     prompt.txt + clip.mp4
  02 The Tail      prompt.txt + clip.mp4
  03 The Slide     prompt.txt + clip.mp4
  04 The Check Up  prompt.txt + clip.mp4
  05 The Bus       prompt.txt + clip.mp4 + logo artwork

THERE ARE NO REFERENCE IMAGES
Four of these five prompts were run with nothing attached. No character sheet,
no style board, no location plate. Everything in the picture is in the text,
which is the reason the text is this long. Shot 05 attaches one file, the logo
that gets painted onto the animal, and the prompt says out loud that the file
is artwork and that nothing else in the frame takes any look from it.

HOW TO RUN ONE
1. Paste prompt.txt into your generator.
2. For shot 05, load the logo into the reference slot. Or drop your own mark in
   its place, or delete the two logo blocks from the prompt and run it without.
3. Change nothing else on the first pass. Run it once as written, see what you
   get, and only then start pulling on it.

NOTES
These prompts are long on purpose. The length is not decoration. Every block is
there to kill a specific failure: a dinosaur that shrinks to horse size, a
second light source, a gimbal smooth camera, a tail that curls like a whip, an
animal that reacts to something it should ignore. Cut the "failed take" lines
and you get the failed take.

The clips in here are the web encodes, same frame size as the masters. They are
for reference and for reposting, not for grading.

Free to use, edit and post. If it works, tell me, I want to see it.

@by.ridge on Instagram
@cg_ridge on X
@by_ridge on YouTube
